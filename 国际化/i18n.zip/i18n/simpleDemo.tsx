import React from "react";
import { View, Text, Button } from "react-native";
 
import { useTranslation } from 'react-i18next'
 
 
const HomeScreen = (props) => {
  // 拿到i18n
  const { i18n } = useTranslation();
 
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>当前语言包:{i18n.language}</Text>
      <Text>{i18n.t("hello")}{i18n.t("world")}</Text>
      <Button title='切换为中文' onPress={() => i18n.changeLanguage('zh')}></Button>
      <Button title='切换为英文' onPress={() => i18n.changeLanguage('en')}></Button>
    </View>
  );
};
 
export default HomeScreen;