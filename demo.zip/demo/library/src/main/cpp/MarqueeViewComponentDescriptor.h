#pragma once

#include <react/renderer/core/ConcreteComponentDescriptor.h>
#include <react/renderer/components/view/ConcreteViewShadowNode.h>
#include <react/renderer/components/view/ViewShadowNode.h>

namespace facebook {
namespace react {

extern const char MarqueeViewComponentName[] = "MarqueeView";

class MarqueeViewProps : public ViewProps {
  public:
      MarqueeViewProps() = default;

      MarqueeViewProps(const PropsParserContext &context, const MarqueeViewProps &sourceProps,
                       const RawProps &rawProps)
          : ViewProps(context, sourceProps, rawProps) {}
};

using MarqueeViewShadowNode = ConcreteViewShadowNode<MarqueeViewComponentName, MarqueeViewProps, ViewEventEmitter>;

class MarqueeViewComponentDescriptor final
    : public ConcreteComponentDescriptor<MarqueeViewShadowNode> {
  public:
      MarqueeViewComponentDescriptor(ComponentDescriptorParameters const &parameters)
          : ConcreteComponentDescriptor(parameters) {}
};

} // namespace react
} // namespace facebook
