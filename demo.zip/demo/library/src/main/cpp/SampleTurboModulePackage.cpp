#include "SampleTurboModulePackage.h"
#include "SampleTurboModuleSpec.h"
#include "PropsDisplayerComponentDescriptor.h"
#include "MarqueeViewComponentDescriptor.h"

using namespace rnoh;
using namespace facebook;

class SampleTurboModuleFactoryDelegate : public TurboModuleFactoryDelegate {
public:
    SharedTurboModule createTurboModule(Context ctx, const std::string &name) const override {
        if (name == "SampleTurboModule") {
            return std::make_shared<NativeSampleTurboModuleSpecJSI>(ctx, name);
        } 
        return nullptr;
    };
};

std::unique_ptr<TurboModuleFactoryDelegate> SampleTurboModulePackage::createTurboModuleFactoryDelegate() {
    return std::make_unique<SampleTurboModuleFactoryDelegate>();
}

std::vector<react::ComponentDescriptorProvider> SampleTurboModulePackage::createComponentDescriptorProviders() {
    return {
        react::concreteComponentDescriptorProvider<react::PropsDisplayerComponentDescriptor>(),
        react::concreteComponentDescriptorProvider<react::MarqueeViewComponentDescriptor>(),
    };
}