// NOTE: This entire file should be codegen'ed.

#include "SampleTurboModuleSpec.h"

using namespace rnoh;
using namespace facebook;

static jsi::Value __hostFunction_NativeSampleTurboCxxModuleSpecJSI_pushStringToHarmony(
    jsi::Runtime &rt,
    react::TurboModule &turboModule,
    const jsi::Value *args, 
    size_t count) {
    return jsi::Value(static_cast<ArkTSTurboModule &>(turboModule).call(rt, "pushStringToHarmony", args, count));
}

NativeSampleTurboModuleSpecJSI::NativeSampleTurboModuleSpecJSI(
    const ArkTSTurboModule::Context ctx,
    const std::string name)
    : ArkTSTurboModule(ctx, name) {
    methodMap_["pushStringToHarmony"] = MethodMetadata{1, __hostFunction_NativeSampleTurboCxxModuleSpecJSI_pushStringToHarmony};
}