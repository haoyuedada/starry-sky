import {
  DisplayMetrics,
  DisplayMetricsManager,
  EventEmitter,
  JSPackagerClient,
  JSPackagerClientConfig,
  NapiBridge, RNAbility, RNInstance,
  RNInstanceOptions,
  RNInstanceRegistry,
  RNOHContext,
  RNOHError,
  TurboModuleProvider,
} from 'rnoh/ts'
import { RNOHLogger, StandardRNOHLogger } from 'rnoh/src/main/ets/RNOH/RNOHLogger'
// @ts-ignore
import libRNOHApp from 'librnoh_app.so'
import common from '@ohos.app.ability.common';
import ArrayList from '@ohos.util.ArrayList';
import { RNInstanceImpl } from 'rnoh/src/main/ets/RNOH/RNInstance';
import { DevToolsController } from 'rnoh/src/main/ets/RNOH/DevToolsController';
import { DevMenu } from 'rnoh/src/main/ets/RNOH/DevMenu';
import { window } from '@kit.ArkUI';;
import { UPRNSDK } from './UPRNSDK'

const RNOH_BANNER = '\n\n\n' +
  '██████╗ ███╗   ██╗ ██████╗ ██╗  ██╗' + '\n' +
  '██╔══██╗████╗  ██║██╔═══██╗██║  ██║' + '\n' +
  '██████╔╝██╔██╗ ██║██║   ██║███████║' + '\n' +
  '██╔══██╗██║╚██╗██║██║   ██║██╔══██║' + '\n' +
  '██║  ██║██║ ╚████║╚██████╔╝██║  ██║' + '\n' +
  '╚═╝  ╚═╝╚═╝  ╚═══╝ ╚═════╝ ╚═╝  ╚═╝' + '\n\n'



export class UPRNSDKImpl implements UPRNSDK {
  public abilityContext: common.UIAbilityContext;
  public eventEmitter: EventEmitter<{ "NEW_ERROR": [RNOHError] }> = new EventEmitter()
  protected lastError: RNOHError | null = null
  protected storage: LocalStorage
  protected napiBridge: NapiBridge = null
  protected turboModuleProvider: TurboModuleProvider
  protected providedLogger: RNOHLogger
  protected logger: RNOHLogger
  protected rnInstanceRegistry: RNInstanceRegistry
  protected window: window.Window | undefined
  protected initializationDateTime: Date
  protected readinessDateTime: Date | undefined
  protected isDebugModeEnabled_: boolean = true
  protected jsPackagerClient: JSPackagerClient | undefined = undefined
  protected displayMetricsManager: DisplayMetricsManager = undefined
  private unregisterWindowListenerCallback: () => void;

  public devToolsController: DevToolsController
  public devMenu: DevMenu
  private inForeground: boolean = false;

  constructor(abilityContext: common.UIAbilityContext) {
    this.abilityContext = abilityContext;
    this.initializationDateTime = new Date()
    this.providedLogger = this.createLogger()
    this.providedLogger.info(RNOH_BANNER)
    this.logger = this.providedLogger.clone("RNAbility")
    const stopTracing = this.logger.clone("onCreate").startTracing()
    console.log('chy=====libRNOHApp', libRNOHApp)
    this.napiBridge = new NapiBridge(libRNOHApp, this.providedLogger)
    const { isDebugModeEnabled } = this.napiBridge.onInit(this.shouldCleanUpRNInstance__hack())
    this.isDebugModeEnabled_ = isDebugModeEnabled
    if (this.logger instanceof StandardRNOHLogger) {
      this.logger.setMinSeverity(this.isDebugModeEnabled_ ? "debug" : "info")
    }
    if (this.isDebugModeEnabled_) {
      this.logger.warn("Debug mode is enabled. Performance is affected.")
    }
    this.rnInstanceRegistry = new RNInstanceRegistry(
      this.providedLogger,
      this.napiBridge,
      this.abilityContext,
      (rnInstance) => this.createRNOHContext({
        rnInstance
      }))
    this.devToolsController = new DevToolsController(this.rnInstanceRegistry, this.providedLogger)
    this.devMenu = new DevMenu(this.devToolsController, this.abilityContext, this.providedLogger)
    this.jsPackagerClient = new JSPackagerClient(this.providedLogger, this.devToolsController, this.devMenu)
    const jsPackagerClientConfig = this.getJSPackagerClientConfig()
    if (jsPackagerClientConfig) {
      this.jsPackagerClient.connectToMetroMessages(jsPackagerClientConfig)
    }

    this.displayMetricsManager = new DisplayMetricsManager(this.logger);
    AppStorage.setOrCreate('RNAbility', this)
    stopTracing()
  }

  onDestroy() {
    const stopTracing = this.logger.clone("onDestroy").startTracing()
    this.jsPackagerClient.onDestroy()
    this.rnInstanceRegistry.forEach(instance => instance.onDestroy())
    this.unregisterWindowListenerCallback();
    stopTracing()
  }

  public getLastError(): RNOHError | null {
    return this.lastError
  }

  public isDebugModeEnabled() {
    return this.isDebugModeEnabled_
  }

  public reportError(err: RNOHError) {
    this.lastError = err
    this.eventEmitter.emit("NEW_ERROR", err)
  }

  protected getJSPackagerClientConfig(): JSPackagerClientConfig | null {
    if (!this.isDebugModeEnabled_) {
      return null
    }
    return {
      host: "localhost",
      port: 8081
    }
  }

  protected shouldCleanUpRNInstance__hack(): boolean {
    return false
  }

  public async createAndRegisterRNInstance(options: RNInstanceOptions): Promise<RNInstance> {
    const stopTracing = this.logger.clone("createAndRegisterRNInstance").startTracing()
    console.log("chy=====createAndRegisterRNInstance1")
    const result = await this.rnInstanceRegistry.createInstance({
      enableDebugger: this.isDebugModeEnabled_,
      devToolsController: this.devToolsController,
      ...options,
    })
    console.log("chy=====createAndRegisterRNInstance2")
    stopTracing()
    return result
  }

  public destroyAndUnregisterRNInstance(rnInstance: RNInstance) {
    const stopTracing = this.logger.clone("destroyAndUnregisterRNInstance").startTracing()
    if (rnInstance instanceof RNInstanceImpl) {
      rnInstance.onDestroy()
    }
    this.rnInstanceRegistry.deleteInstance(rnInstance.getId())
    stopTracing()
  }

  public createRNOHContext({rnInstance}: { rnInstance: RNInstance }) {
    if (!(rnInstance instanceof RNInstanceImpl)) {
      throw new Error("RNInstance must extend RNInstanceImpl")
    }
    return new RNOHContext("0.72.5", rnInstance, this.providedLogger, AppStorage.get('RNAbility') as RNAbility)
  }

  protected createLogger(): RNOHLogger {
    return new StandardRNOHLogger(AppStorage.get('RNAbility') as RNAbility);
  }

  public getLogger(): RNOHLogger {
    return this.providedLogger
  }

  public async onWindowSetup(win: window.Window) {
    const stopTracing = this.logger.clone("onWindowSetup").startTracing()
    await win.setWindowLayoutFullScreen(true)
    stopTracing()
  }

  onMemoryLevel(level) {
    const stopTracing = this.logger.clone("onWindowStageCreate").startTracing()
    const MEMORY_LEVEL_NAMES = ["MEMORY_LEVEL_MODERATE", "MEMORY_LEVEL_LOW", "MEMORY_LEVEL_CRITICAL"]
    this.logger.debug("Received memory level event: " + MEMORY_LEVEL_NAMES[level])
    this.napiBridge.onMemoryLevel(level)
    stopTracing()
  }

  onConfigurationUpdate(config) {
    const stopTracing = this.logger.clone("onConfigurationUpdate").startTracing()
    this.displayMetricsManager.updateDisplayMetrics()
    this.rnInstanceRegistry?.forEach((rnInstance) => rnInstance.onConfigurationUpdate(config))
    stopTracing()
  }

  onForeground() {
    const stopTracing = this.logger.clone("onForeground").startTracing()
    this.inForeground = true
    this.rnInstanceRegistry?.forEach((rnInstance) => rnInstance.onForeground())
    stopTracing()
  }

  onBackground() {
    const stopTracing = this.logger.clone("onBackground").startTracing()
    this.inForeground = false
    this.rnInstanceRegistry?.forEach((rnInstance) => rnInstance.onBackground())
    stopTracing()
  }

  public getAbilityState(): "FOREGROUND" | "BACKGROUND" {
    return this.inForeground ? "FOREGROUND" : "BACKGROUND";
  }

  onBackPress() {
    const stopTracing = this.logger.clone("onBackPress").startTracing()
    this.rnInstanceRegistry?.forEach((rnInstance) => rnInstance.onBackPress())
    stopTracing()
    return true;
  }

  public getDisplayMetrics(): DisplayMetrics {
    return this.displayMetricsManager.getDisplayMetrics();
  }
}
